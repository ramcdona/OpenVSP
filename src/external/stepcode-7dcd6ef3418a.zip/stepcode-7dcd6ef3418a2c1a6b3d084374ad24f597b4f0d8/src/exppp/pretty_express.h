#ifndef PRETTY_EXPRESS_H
#define PRETTY_EXPRESS_H

void EXPRESSout( Express e );

#endif /* PRETTY_EXPRESS_H */
