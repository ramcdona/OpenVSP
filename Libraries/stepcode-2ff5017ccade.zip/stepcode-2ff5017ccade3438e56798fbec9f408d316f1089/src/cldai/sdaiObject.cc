#include "clstepcore/sdai.h"

SDAI_sdaiObject::SDAI_sdaiObject() {
}

SDAI_sdaiObject::~SDAI_sdaiObject() {
}
