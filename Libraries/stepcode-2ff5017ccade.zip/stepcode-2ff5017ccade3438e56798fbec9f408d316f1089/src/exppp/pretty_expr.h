#ifndef PRETTY_EXPR_H
#define PRETTY_EXPR_H

#ifdef __cplusplus
extern "C" {
#endif

#include "../express/expbasic.h"
#include "../express/express.h"

#define EXPR_out(e,p) EXPR__out(e,p,OP_UNKNOWN)
#define EXPRop2_out(oe,string,paren,pad) \
EXPRop2__out(oe,string,paren,pad,OP_UNKNOWN)
#define EXPRop_out(oe,paren) EXPRop__out(oe,paren,OP_UNKNOWN)

void EXPRop__out( struct Op_Subexpression * oe, int paren, unsigned int previous_op );
void EXPRop1_out( struct Op_Subexpression * eo, const char * opcode, int paren );
void EXPRop2__out( struct Op_Subexpression * eo, const char * opcode, int paren, int pad, unsigned int previous_op );
void EXPR__out( Expression e, int paren, unsigned int previous_op );
void EXPRbounds_out( TypeBody tb );

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* PRETTY_EXPR_H */

