#ifndef __FACTORY_H_
#define __FACTORY_H_

#include "sc_export.h"

SC_EXPRESS_EXPORT void FACTORYinitialize(void);

#endif /* __FACTORY_H_ */
